arus <- 10
hambatan <- 500
tegangan <- arus * hambatan

cat(sprintf("Voltase = %d\n",tegangan))

