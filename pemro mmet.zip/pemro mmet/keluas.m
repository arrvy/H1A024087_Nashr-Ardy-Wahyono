phi = 3.14;
jari_jari = 7.0;
luas = phi * jari_jari * jari_jari;
keliling = 2 * phi * jari_jari;
fprintf ("luas lingkaran %d\n", luas);
fprintf ("keliling lingkaran %d\n", keliling);