jawab = 100
hasil = jawab - 10

cat("Jawab =", hasil + 6, "\n")

