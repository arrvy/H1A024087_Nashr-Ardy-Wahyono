A <- as.numeric(readline(prompt = "Masukkan angka pertama A: "))
B <- as.numeric(readline(prompt = "Masukkan angka kedua B: "))
C <- A + B

cat(sprintf("Hasil jumlahnya adalah C = %d\n", C))