jawab = 100;
hasil = jawab - 10;
fprintf('jawaban = %d', hasil + 6);