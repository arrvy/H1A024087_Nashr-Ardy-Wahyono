A = input('Masukkan angka pertama A : ');
B = input('Masukkan angka kedua B : ');
C =A+B;
fprintf('Hasil jumlahnnya adalah C = %d\n',C);