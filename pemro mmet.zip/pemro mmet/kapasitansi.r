Q <- as.numeric(readline(prompt = "Masukkan muatan Q: "))
V <- as.numeric(readline(prompt = "Masukkan tegangan V: "))
K <- Q / V

cat(sprintf("Nilai kapasitansi adalah K = %f",C,"Farad"))