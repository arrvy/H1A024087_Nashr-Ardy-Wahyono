Q = input('Masukkan nilai muatan Q : ');
V = input('Masukkan nilai tegangan V : ');
K = Q / V
fprintf('Hasil jumlahnnya adalah C = %d\n',C);