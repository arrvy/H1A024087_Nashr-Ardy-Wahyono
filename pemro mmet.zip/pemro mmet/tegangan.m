Arus = 10;
Hambatan = 500;
Tegangan = Arus * Hambatan;
fprintf('Voltase = %d',Tegangan);