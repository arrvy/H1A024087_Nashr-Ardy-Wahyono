A = input("Masukkan nilai sisi A: ");
B = input("Masukkan nilai sisi B: ");
C = sqrt (A*A + B*B)
fprintf("Panjang sisi miring C = %d\n");